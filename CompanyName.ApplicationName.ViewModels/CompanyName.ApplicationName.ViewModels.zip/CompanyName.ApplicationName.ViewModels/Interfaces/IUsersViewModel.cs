﻿using CompanyName.ApplicationName.DataModels.Collections;

namespace CompanyName.ApplicationName.ViewModels.Interfaces
{
    public interface IUsersViewModel
    {
        Users Users { get; set; }
    }
}